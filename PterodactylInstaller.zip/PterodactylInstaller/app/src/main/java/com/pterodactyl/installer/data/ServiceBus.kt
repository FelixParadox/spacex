package com.pterodactyl.installer.data

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object ServiceBus {

    data class InstallEvent(val type: String, val message: String)
    data class InstallDoneEvent(
        val success: Boolean,
        val message: String,
        val data: Map<String, String>?
    )

    private val _installLog = MutableSharedFlow<InstallEvent>(extraBufferCapacity = 512)
    val installLog: SharedFlow<InstallEvent> = _installLog.asSharedFlow()

    private val _installStage = MutableSharedFlow<String>(extraBufferCapacity = 16)
    val installStage: SharedFlow<String> = _installStage.asSharedFlow()

    private val _installDone = MutableSharedFlow<InstallDoneEvent>(extraBufferCapacity = 8)
    val installDone: SharedFlow<InstallDoneEvent> = _installDone.asSharedFlow()

    fun emitLog(type: String, msg: String) = _installLog.tryEmit(InstallEvent(type, msg))
    fun emitStage(stage: String) = _installStage.tryEmit(stage)
    fun emitDone(ok: Boolean, msg: String, data: Map<String, String>?) =
        _installDone.tryEmit(InstallDoneEvent(ok, msg, data))

    data class SshEvent(val type: String, val message: String)
    private val _sshOutput = MutableSharedFlow<SshEvent>(extraBufferCapacity = 1024)
    val sshOutput: SharedFlow<SshEvent> = _sshOutput.asSharedFlow()

    private val _sshStatus = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val sshStatus: SharedFlow<String> = _sshStatus.asSharedFlow()

    fun emitSsh(type: String, msg: String) = _sshOutput.tryEmit(SshEvent(type, msg))
    fun emitSshStatus(status: String) = _sshStatus.tryEmit(status)

    // Command queue dari UI → InstallService
    private val _installCommand = MutableSharedFlow<String>(extraBufferCapacity = 32)
    val installCommand: SharedFlow<String> = _installCommand.asSharedFlow()
    fun sendInstallCommand(cmd: String) = _installCommand.tryEmit(cmd)

    @Volatile var installRunning = false
    @Volatile var sshRunning = false
}