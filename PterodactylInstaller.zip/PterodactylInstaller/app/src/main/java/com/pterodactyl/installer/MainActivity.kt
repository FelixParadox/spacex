package com.pterodactyl.installer

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.pterodactyl.installer.data.UpdateChecker
import com.pterodactyl.installer.data.UpdateWorker
import com.pterodactyl.installer.ui.InstallFragment
import com.pterodactyl.installer.ui.SettingsActivity
import com.pterodactyl.installer.ui.SshFragment
import com.pterodactyl.installer.ui.UpdateDialog
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private var pendingDialog: UpdateDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        UpdateWorker.schedule(this)

        findViewById<ImageView>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        if (savedInstanceState == null) {
            loadFragment(InstallFragment())
            bottomNav.selectedItemId = R.id.nav_install
        }

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_install -> { loadFragment(InstallFragment()); true }
                R.id.nav_ssh -> { loadFragment(SshFragment()); true }
                else -> false
            }
        }

        checkForUpdates()
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun checkForUpdates() {
        lifecycleScope.launch {
            val info = UpdateChecker(this@MainActivity).checkForUpdate() ?: return@launch
            if (isFinishing || isDestroyed) return@launch
            pendingDialog = UpdateDialog(this@MainActivity, info,
                onDownload = { }, onDismiss = { pendingDialog = null }).also { it.show() }
        }
    }
}