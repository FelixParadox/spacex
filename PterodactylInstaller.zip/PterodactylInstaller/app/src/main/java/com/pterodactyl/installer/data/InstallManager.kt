package com.pterodactyl.installer.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class InstallParams(
    val ipVps: String,
    val pwVps: String,
    val domainPanel: String,
    val domainNode: String,
    val usernamePanel: String,
    val passwordPanel: String,
    val gmailPanel: String
)

enum class Stage { IDLE, PANEL, WINGS, NODE, DONE, ERROR }

class InstallManager(
    private val params: InstallParams,
    private val onLog: (type: String, msg: String) -> Unit,
    private val onStage: (Stage) -> Unit,
    private val onComplete: (success: Boolean, message: String, data: Map<String, String>?) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var client: SshClient? = null
    private var currentExec: SshClient.ExecHandle? = null
    private var stopped = false

    fun start() {
        scope.launch {
            client = SshClient(params.ipVps, params.pwVps)
            if (!client!!.connect()) {
                onLog("error", "❌ Gagal SSH ke ${params.ipVps}")
                onComplete(false, "SSH gagal", null)
                return@launch
            }
            onLog("info", "✅ SSH terhubung")
            runPanel()
        }
    }

    private fun runPanel() {
        if (stopped) return
        onStage(Stage.PANEL)
        onLog("panel", "📦 Tahap 1: Install Panel")
        runStageWithAutoAnswer(
            cmd = "bash <(curl -s https://pterodactyl-installer.se)",
            tag = "panel",
            answerFn = { s -> answerPanel(s) },
            onSuccess = {
                onLog("success", "✅ Panel selesai")
                runWings()
            }
        )
    }

    private fun answerPanel(s: String): String? {
        val p = params
        return when {
            "Input 0-6" in s -> "0\n"
            "(y/N)" in s -> "y\n"
            "(Y/n)" in s -> "Y\n"
            "Database name" in s -> "\n"
            "Database username" in s -> "${p.usernamePanel}\n"
            "Password (press enter" in s -> "${p.passwordPanel}\n"
            "Select timezone" in s -> "Asia/Jakarta\n"
            "Provide the email address" in s -> "${p.gmailPanel}\n"
            "Email address for the initial admin account" in s -> "${p.gmailPanel}\n"
            "Username for the initial admin account" in s -> "${p.usernamePanel}\n"
            "First name for the initial admin account" in s -> "${p.usernamePanel}\n"
            "Last name for the initial admin account" in s -> "${p.usernamePanel}\n"
            "Password for the initial admin account" in s -> "${p.passwordPanel}\n"
            "Set the FQDN of this panel" in s -> "${p.domainPanel}\n"
            "automatically configure UFW" in s -> "y\n"
            "automatically configure HTTPS" in s -> "y\n"
            "Select the appropriate number" in s -> "1\n"
            "I agree that this HTTPS request" in s -> "y\n"
            "Proceed anyways" in s -> "y\n"
            "(yes/no)" in s -> "y\n"
            "Initial configuration completed" in s -> "y\n"
            "Still assume SSL?" in s -> "y\n"
            "Please read the Terms of Service" in s -> "y\n"
            "(A)gree/(C)ancel" in s -> "A\n"
            else -> null
        }
    }

    private fun runWings() {
        if (stopped) return
        onStage(Stage.WINGS)
        onLog("wings", "🪶 Tahap 2: Install Wings")
        runStageWithAutoAnswer(
            cmd = "bash <(curl -s https://pterodactyl-installer.se)",
            tag = "wings",
            answerFn = { s -> answerWings(s) },
            onSuccess = {
                onLog("success", "✅ Wings selesai")
                runNode()
            }
        )
    }

    private fun answerWings(s: String): String? {
        val p = params
        return when {
            "Input 0-6" in s -> "1\n"
            "(y/N)" in s -> "y\n"
            "(Y/n)" in s -> "Y\n"
            "Enter the panel address" in s -> "${p.domainPanel}\n"
            "Database host username" in s -> "${p.usernamePanel}\n"
            "Database host password" in s -> "${p.usernamePanel}\n"
            "Set the FQDN" in s -> "${p.domainNode}\n"
            "Enter email address for Let" in s -> "${p.gmailPanel}\n"
            else -> null
        }
    }

    private fun runNode() {
        if (stopped) return
        onStage(Stage.NODE)
        onLog("node", "📦 Tahap 3: Buat Node")
        runStageWithAutoAnswer(
            cmd = "bash <(curl -s https://raw.githubusercontent.com/paradoxtools-v/felixbetates/refs/heads/main/node.sh)",
            tag = "node",
            answerFn = { s -> answerNode(s) },
            onSuccess = {
                onLog("success", "✅ Node selesai")
                onStage(Stage.DONE)
                onComplete(true, "Install selesai!", mapOf(
                    "domain_panel" to params.domainPanel,
                    "domain_node" to params.domainNode,
                    "username" to params.usernamePanel,
                    "password" to params.passwordPanel,
                    "email" to params.gmailPanel
                ))
                client?.disconnect()
            }
        )
    }

    private fun answerNode(s: String): String? {
        val p = params
        return when {
            "Masukkan domain" in s -> "${p.domainNode}\n"
            "(y/N)" in s -> "y\n"
            "(Y/n)" in s -> "Y\n"
            else -> null
        }
    }

    private fun runStageWithAutoAnswer(
        cmd: String,
        tag: String,
        answerFn: (String) -> String?,
        onSuccess: () -> Unit
    ) {
        if (stopped) return
        val buffer = StringBuilder()

        currentExec = client?.openExec(
            command = cmd,
            onOutput = { chunk ->
                buffer.append(chunk)
                onLog(tag, chunk.trimEnd())
                val last = buffer.lines().takeLast(3).joinToString("\n")
                val ans = answerFn(last)
                if (ans != null) {
                    currentExec?.write(ans)
                    buffer.setLength(0)
                }
            },
            onError = { err -> onLog("error", err.trimEnd()) },
            onComplete = { code ->
                if (stopped) {
                    onLog("warning", "⛔ Stage $tag dihentikan")
                    return@openExec
                }
                if (code == 0 || code == -1) onSuccess()
                else {
                    onLog("error", "❌ Stage $tag exit $code")
                    onComplete(false, "Stage $tag gagal", null)
                }
            }
        )
    }

    fun sendCommand(cmd: String) {
        currentExec?.writeLine(cmd)
        onLog("info", "📤 $cmd")
    }

    fun stop() {
        stopped = true
        currentExec?.stop()
        client?.disconnect()
        onLog("warning", "⛔ Instalasi dihentikan")
    }
}