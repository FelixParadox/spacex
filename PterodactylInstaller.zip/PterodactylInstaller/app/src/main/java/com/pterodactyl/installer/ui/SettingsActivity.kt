package com.pterodactyl.installer.ui

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.pterodactyl.installer.BuildConfig
import com.pterodactyl.installer.R
import com.pterodactyl.installer.data.UpdateChecker
import kotlinx.coroutines.launch

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<TextView>(R.id.tvVersion).text =
            "Versi ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"

        findViewById<Button>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnCheckUpdate).setOnClickListener {
            lifecycleScope.launch {
                val info = UpdateChecker(this@SettingsActivity).checkForUpdate()
                if (info != null) {
                    UpdateDialog(this@SettingsActivity, info, {}, {}).show()
                } else {
                    Toast.makeText(this@SettingsActivity,
                        "✅ Sudah versi terbaru", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}