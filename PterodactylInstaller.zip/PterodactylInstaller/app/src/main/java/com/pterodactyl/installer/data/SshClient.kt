package com.pterodactyl.installer.data

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.ChannelShell
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.OutputStream

class SshClient(
    private val host: String,
    private val password: String,
    private val user: String = "root",
    private val port: Int = 22
) {
    private var session: Session? = null

    suspend fun connect(): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsch = JSch()
            session = jsch.getSession(user, host, port).apply {
                setPassword(password)
                setConfig("StrictHostKeyChecking", "no")
                setConfig("PreferredAuthentications", "password,keyboard-interactive")
                timeout = 20_000
                connect(20_000)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            session = null
            false
        }
    }

    fun openExec(
        command: String,
        onOutput: (String) -> Unit,
        onError: (String) -> Unit,
        onComplete: (Int) -> Unit
    ): ExecHandle? {
        val s = session ?: return null
        return try {
            val channel = s.openChannel("exec") as ChannelExec
            channel.setCommand(command)
            channel.setPty(true)
            channel.setErrStream(null, true)

            val input: InputStream = channel.inputStream
            val output: OutputStream = channel.outputStream

            channel.connect(10_000)

            Thread {
                try {
                    val buf = ByteArray(4096)
                    var n: Int
                    while (input.read(buf).also { n = it } != -1) {
                        if (n > 0) onOutput(String(buf, 0, n))
                    }
                } catch (_: Exception) { }
            }.start()

            val err: InputStream? = channel.errStream
            if (err != null) {
                Thread {
                    try {
                        val buf = ByteArray(4096)
                        var n: Int
                        while (err.read(buf).also { n = it } != -1) {
                            if (n > 0) onError(String(buf, 0, n))
                        }
                    } catch (_: Exception) { }
                }.start()
            }

            Thread {
                try {
                    while (!channel.isClosed) Thread.sleep(200)
                    onComplete(channel.exitStatus)
                } catch (_: Exception) { onComplete(-1) }
            }.start()

            ExecHandle(channel, output)
        } catch (e: Exception) {
            e.printStackTrace()
            onError("❌ ${e.message}")
            null
        }
    }

    fun openShell(
        onOutput: (String) -> Unit,
        onError: (String) -> Unit,
        onClose: () -> Unit
    ): ShellHandle? {
        val s = session ?: return null
        return try {
            val channel = s.openChannel("shell") as ChannelShell
            channel.setPtyType("xterm")
            channel.setPtySize(120, 40, 800, 480)

            val input: InputStream = channel.inputStream
            val output: OutputStream = channel.outputStream
            channel.connect(10_000)

            Thread {
                try {
                    val buf = ByteArray(4096)
                    var n: Int
                    while (input.read(buf).also { n = it } != -1) {
                        if (n > 0) onOutput(String(buf, 0, n))
                    }
                } catch (_: Exception) {
                } finally { onClose() }
            }.start()

            ShellHandle(channel, output)
        } catch (e: Exception) {
            e.printStackTrace()
            onError("❌ ${e.message}")
            null
        }
    }

    fun disconnect() {
        try { session?.disconnect() } catch (_: Exception) { }
        session = null
    }

    class ExecHandle(val channel: ChannelExec, private val out: OutputStream) {
        fun write(data: String) {
            try { out.write(data.toByteArray()); out.flush() } catch (_: Exception) { }
        }
        fun writeLine(data: String) = write(data + "\n")
        fun stop() { try { channel.disconnect() } catch (_: Exception) { } }
        fun isClosed() = channel.isClosed
    }

    class ShellHandle(val channel: ChannelShell, private val out: OutputStream) {
        fun write(data: String) {
            try { out.write(data.toByteArray()); out.flush() } catch (_: Exception) { }
        }
        fun writeLine(data: String) = write(data + "\n")
        fun close() { try { channel.disconnect() } catch (_: Exception) { } }
    }
}